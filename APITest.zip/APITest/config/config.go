package config

// File ini disiapkan untuk konfigurasi global aplikasi,
// seperti environment variable, secret, dsb.
// Saat ini masih kosong tapi tetap dipertahankan agar struktur rapi.
